<?php
/**
 * Plugin Name: Burr & Forman Document Writer
 * Description: Converts custom post types and related fields into docx files
 * Version: 2.2
 * Author: Creative Mischief
 * Author URI: http://www.creative-mischief.com
 *
 * @license   http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */

if(!defined('ABSPATH')) { exit; }

define("SKM_DOC_WRITER_ROOT", dirname(__FILE__));
define("SKM_DOC_WRITER_URL", plugins_url('', __FILE__));

require(sprintf("%s/autoload.php", SKM_DOC_WRITER_ROOT));

if(class_exists('DocWriterHooks')) {
	new DocWriterHooks();
}
//test
if(class_exists('DocWriterCron')) {
	add_action('skm_doc_writer_cron', array('DocWriterCron', 'cron_func'));
	register_activation_hook(__FILE__, array('DocWriterCron', 'activate'));
  	register_deactivation_hook(__FILE__, array('DocWriterCron', 'deactivate'));
}