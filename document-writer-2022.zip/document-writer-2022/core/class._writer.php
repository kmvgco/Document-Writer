<?php
class DocWriter {
	private $colors = array(
		'grey' => '595959',
		'black' => '000000',
		'blue1' => '02215C',
		'blue2' => '02225E',
		'blue3' => '27477c',
		'orange' => 'E06C22',
		'dark blue' => '0b134d',
		'red' => 'ce0c13'
	);

	public function __construct($data) {
		$this->doc = new \PhpOffice\PhpWord\PhpWord();
		$this->doc->getCompatibility()->setOoxmlVersion(14);
		$this->data = $data;
		$this->setTextStyles();
		$this->section_cover = $this->doc->addSection(array(
			'paperSize' => 'Letter',
			'marginLeft' => 0,
			'marginRight' => 0,
			'marginTop' => 0,
			'marginBottom' => 0,
		));
		$this->section = $this->doc->addSection(array(
			'paperSize' => 'Letter',
			'marginLeft' => 750,
			'marginRight' => 750,
			'marginTop' => 1440,
			'marginBottom' => 1440,
		));
		$this->setDefaults();
		$this->setHeader();
	}

	private function setDefaults() {
		$this->doc->setDefaultFontName('Calibri');
		$this->doc->setDefaultFontSize(12);
		$this->setDefaultParagraphStyle();
	}

	private function setDefaultParagraphStyle() {
		//array('line' => 500, 'rule' => 'exact')
		$this->doc->setDefaultParagraphStyle(array(
			'space' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(1),
			'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(0), 
			'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(0),
			'align' => 'left',
		));
	}

	private function setHeader() {
		$this->header = $this->section->addHeader();
		$table = $this->header->addTable();
		$table->addRow();
		$table->addCell(4800);
		$cell = $table->addCell(4200, array('gridSpan' => 1, 'valign' => 'top', ''));
		$cell->addImage(sprintf("%s/assets/images/watermark.png", SKM_DOC_WRITER_URL),
			array(
				'width' => 266,
				'height' => 16,
				'align' => 'right'
			)
		);
		$table->addRow();
		$table->addCell(4500);
	}

	public function setTextStyles() {
		$this->textStyles = array(
			'calibri_11.5' => array(
				'name' => 'Calibri',
				'size' => 11.5,
				'color' => $this->colors['black']
			),
			'calibri_12' => array(
				'name' => 'Calibri',
				'size' => 12,
				'color' => $this->colors['black']
			),
			'calibri_12_bold' => array(
				'name' => 'Calibri',
				'size' => 12,
				'color' => $this->colors['black'],
				'bold' => true,
			),
			'calibri_13' => array(
				'name' => 'Calibri',
				'size' => 13,
				'color' => $this->colors['black'],
				'bold' => true
			),
			'calibri_14.5' => array(
				'name' => 'Calibri',
				'size' => 14.5,
				'color' => $this->colors['black']
			),
			'heading1' => array(
				'name' => 'Calibri',
				'size' => 25,
				'bold' => true,
				'color' => $this->colors['dark blue'],
			),
			'heading2' => array(
				'name' => 'Calibri',
				'size' => 18,
				'bold' => true,
				'color' => $this->colors['red'],
			),
			'heading3' => array(
				'name' => 'Calibri',
				'size' => 14,
				'bold' => true,
				'color' => $this->colors['red'],
			),
			'heading4' => array(
				'name' => 'Calibri',
				'size' => 14,
				'bold' => true,
				'color' => $this->colors['dark_blue'],
			),
			'heading5' => array(
				'name' => 'Calibri',
				'size' => 14,
				'bold' => true,
				'color' => $this->colors['dark_blue'],
			),
			'heading6' => array(
				'name' => 'Calibri',
				'size' => 14,
				'bold' => true,
				'color' => $this->colors['dark_blue'],
			),
			'proposal_name' => array(
				'name' => 'Calibri',
				'size' => 16.5,
				'color' => $this->colors['dark blue'],
				'bold' => true
			),
			'service_title' => array(
				'name' => 'Calibri',
				'size' => 24,
				'color' => $this->colors['dark blue'],
				'bold' => true
			),
			'attorney_title' => array(
				'name' => 'Calibri',
				'size' => 16,
				'color' => $this->colors['dark blue']
			),
			'locations_title' => array(
				'name' => 'Calibri',
				'size' => 19.5,
				'color' => $this->colors['dark blue']
			),
			'attorney_services' => array(
				'name' => 'Calibri',
				'size' => 12,
				'color' => $this->colors['dark blue']
			),
			'location_title' => array(
				'name' => 'Calibri',
				'size' => 12,
				'color' => $this->colors['red'],
				'bold' => true
			),
			'location_address' => array(
				'name' => 'Calibri',
				'size' => 11,
				'color' => $this->colors['grey']
			),
			'location_body' => array(
				'name' => 'Calibri',
				'size' => 11,
				'color' => $this->colors['grey']
			),
			'link' => array(
				'name' => 'Calibri',
				'size' => 11.5,
				'color' => $this->colors['blue2'],
				'underline' => \PhpOffice\PhpWord\Style\Font::UNDERLINE_SINGLE
			),
			'face_link' => array(
				'name' => 'Calibri',
				'size' => 11.5,
				'color' => $this->colors['blue2'],
				'underline' => \PhpOffice\PhpWord\Style\Font::UNDERLINE_SINGLE
			),
			'face_page' => array(
				'name' => 'Calibri', 
				'size' => 15,
				'color' => $this->colors['black'],
			),
			'face_title' => array(
				'name' => 'Calibri',
				'size' => 11.5,
				'bold' => true,
				'color' => $this->colors['blue3'],
			),
			'face_content' => array(
				'name' => 'Calibri',
				'size' => 11.5,
				'color' => $this->colors['black'],
			),
		);

		$this->doc->addTitleStyle(1, $this->textStyles['heading1'], []);
		$this->doc->addTitleStyle(2, $this->textStyles['heading2'], []);
		$this->doc->addTitleStyle(3, $this->textStyles['heading3'], []);
		$this->doc->addTitleStyle(4, $this->textStyles['heading4'], []);
		$this->doc->addTitleStyle(5, $this->textStyles['heading5'], []);
		$this->doc->addTitleStyle(6, $this->textStyles['heading6'], []);

		$this->doc->addParagraphStyle('cpStyle', array('align'=>'left'));
		$this->doc->addFontStyle('CoverHeadingOne', array('bold' => true, 'size' => 16, 'name'=>'Calibri', 'color'=> '0b134d'));
		$this->doc->addFontStyle('CoverHeadingTwo', array('normal' => true, 'size' => 25, 'name'=>'Calibri', 'color'=> '0b134d'));
		$this->doc->addFontStyle('CoverHeadingThree', array('bold' => true, 'size' => 14, 'name'=>'Calibri', 'color'=> '0b134d'));
		$this->doc->addFontStyle('CoverHeadingThreeSub', array('normal' => true, 'size' => 14, 'name'=>'Calibri', 'color'=> '0b134d'));
		$this->doc->addFontStyle('CoverHeadingfour', array('normal' => false, 'size' => 20, 'name'=>'Calibri', 'color'=> '0b134d'));

	}

	public function write() {
		$this->writeFirstPage();
		
		$this->writeServices();

		if(!empty($this->data['generate_face_pages']) && $this->data['generate_face_pages'] != "false") {
			$this->writeFacePages();
		}
		$this->writeAttorneys();
		
		$this->writeLocations();

		$this->saveFile();
	}

	private function saveFile() {
		$t = microtime(true);
		$docfileName = "Burr_Forman_$t.docx";

		$writer = \PhpOffice\PhpWord\IOFactory::createWriter($this->doc, 'Word2007');
		$this->filepath = sprintf("%s/tmp/%s", SKM_DOC_WRITER_ROOT, $docfileName);
		$this->filename = $docfileName;
		$writer->save($this->filepath);
	}

	private function writeFirstPage() {
		$this->section_cover->addImage( SKM_DOC_WRITER_ROOT.'/assets/images/pitch-bg.png', array( 'width'=>616, 'height' =>930, 'marginTop' => -1440, 'marginLeft' => -1440, 'positioning' => 'absolute','align' => 'start', 'wrappingStyle' => 'behind' ) );
		$this->section_cover->addTextBreak(15);
		$this->section_cover->addImage( SKM_DOC_WRITER_ROOT.'/assets/images/burr-logo-main-page.png', array( 'width'=>250, 'height' =>60, 'align' => 'center') );
		/*$this->section_cover->addLine(
			array(
				'width'       => \PhpOffice\PhpWord\Shared\Converter::cmToPixel(15),
				'height'      => \PhpOffice\PhpWord\Shared\Converter::cmToPixel(0),
				'positioning' => 'relative',
				'weight'      => 10,
				'color' => '0b134d'
			)
		);*/
	/*	$this->section_cover->addLine(
			array(
				'width'            => \PhpOffice\PhpWord\Shared\Converter::cmToPixel(2),
				'height'           => \PhpOffice\PhpWord\Shared\Converter::cmToPixel(0),
				'positioning'      => 'relative',
				'marginLeft'       => \PhpOffice\PhpWord\Shared\Converter::cmToPixel(30),
				'weight'      => 5,
				'color'            => '0b134d',
			)
		);*/
		$textrun = $this->section_cover->createTextRun('pStyle');
		$textrun->addTextBreak(1);
		$textrun->addText(htmlspecialchars("\t\t\t\t\t\t"."________"), 'CoverHeadingOne');
		$textrun->addTextBreak(2);
		$textrun->addText(htmlspecialchars("\t\t\t\t\t\t"."PREPARED FOR:"), 'CoverHeadingOne');
		$textrun->addTextBreak(2);
		if (strlen($this->data['proposal_name']) < 24) {
			$textrun->addText(htmlspecialchars("\t\t\t\t\t\t".$this->data['proposal_name']), 'CoverHeadingTwo');
		} else {
			$chunks = str_split($this->data['proposal_name'], 23);
			foreach ($chunks as $chunk) {
				$textrun->addText(htmlspecialchars("\t\t\t\t\t\t".$chunk), 'CoverHeadingTwo');
				$textrun->addTextBreak(1);
			}
		}
		$textrun->addTextBreak(2);
		$textrun->addText(htmlspecialchars("\t\t\t\t\t\t"."Date: "), 'CoverHeadingThree');
		$textrun->addText(htmlspecialchars(date('F d, Y')), 'CoverHeadingThreeSub');
		$textrun->addTextBreak(2);
		$textrun->addText(htmlspecialchars("\t\t\t\t\t\t"."Prepared By: "), 'CoverHeadingThree');
		$textrun->addText(htmlspecialchars($this->data['preparer_name']), 'CoverHeadingThreeSub');
		$textrun->addTextBreak(6);
		$textrun->addText(htmlspecialchars("\t\t\t\t\t"."PRIVILEGED AND CONFIDENTIAL"), 'CoverHeadingfour');
		$textrun->addTextBreak(1);
		$textrun->addText(htmlspecialchars("\t\t\t\t\t\t\t\t"."___________"), 'CoverHeadingOne');

		//$cover_intro = $this->data['intro_text'];
		//$this->renderHTML($cover_intro);
		
	}

	private function writeServices() {
		
		foreach($this->data['services'] as $service) {
			$this->writeService($service);
			$this->section->addTextBreak(2);
		}
		$this->section->addPageBreak();
	}

	private function writeService($service) {
		
		$this->section->addText(
			htmlspecialchars($service['post_title']), 
			array(
				'name' => 'Calibri',
				'size' => 22,
				'color' => '0b134d',
				'bold' => true
			),
			array(
				'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(0),
				'keepNext' => true
			)
		);
		$this->section->addImage( SKM_DOC_WRITER_ROOT.'/assets/images/line.jpg', array( 'width'=>30, 'height' =>10, 'align' => 'left') );
		$this->section->addTextBreak(2);
		$service['post_content'] = str_replace('<p>', "<p style='font-size: 12pt; line-height:1; font-family: Calibri; padding-top: 20pt;'>", $service['post_content']);
		$service['post_content'] = str_replace('</p>', "</p><br/>", $service['post_content']);
		$service['post_content'] = str_replace('</ul>', "</ul><br/>", $service['post_content']);
		$service['post_content'] = str_replace('</strong>', "</strong><br/>", $service['post_content']);
		$service['post_content'] = str_replace('&nbsp;', "", $service['post_content']);
		$this->renderHTML($service['post_content']);
	}

	private function writeFacePages() {
		//$this->section->addPageBreak();
		//$this->section->addTextBreak(2);
		$this->section->addText(
			htmlspecialchars("Burr & Forman’s Team"),
			array(
				'name' => 'Calibri',
				'size' => 22,
				'color' => '0b134d',
				'bold' => true
			),
			array(
				'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(0),
			)
		);
		$this->section->addImage( SKM_DOC_WRITER_ROOT.'/assets/images/line.jpg', array( 'width'=>30, 'height' =>10, 'align' => 'left') );
		$this->section->addTextBreak(2);
		$table = $this->section->addTable(array('cellMargin' => 50));
		foreach($this->data['attorneys'] as $key => $attorney) {
			if(($key) % 4 == 0) {
				$table->addRow();
			}
			$writer = new AttorneyWriter($attorney, $this->doc, $this->section);
			$writer->writeFacePage($table);
		}
		if ((count($this->data['attorneys']) % 8) > 0 && (count($this->data['attorneys']) % 8) < 5 ) { 
			$this->section->addPageBreak();
		}
	}

	private function writeAttorneys() {
		foreach($this->data['attorneys'] as $attorney) {
			$this->writeAttorney($attorney);

			//$this->section->addTextBreak(2);
			$this->section->addPageBreak();
		}
	}

	private function writeAttorney($attorney) {
		$writer = new AttorneyWriter($attorney, $this->doc, $this->section);
		$writer->write();
	}

	public function attorneyHasAid($attorney, $key) {
		return !empty($attorney[$key]) && (!empty($attorney[$key]['name']) || !empty($attorney[$key]['phone']) || !empty($attorney[$key]['email']));
	}

	public function addSimpleList($list) {
		$htmlString = "<ul>";
		foreach($list as $listItem) {
			$htmlString .= "   <li>$listItem</li>";
		}
		$htmlString .= "</ul>";
		$this->renderHTML($htmlString);
	}

	public function renderHTML($content) {
		\PhpOffice\PhpWord\Shared\Html::addHtml($this->section, $content);
	}

	private function writeLocations() {
		//$this->section->addPageBreak();
		//$this->section->addTextBreak(2);
		$this->section->addText(
			'Office Locations',
			array(
				'name' => 'Calibri',
				'size' => 22,
				'color' => '0b134d',
				'bold' => true
			),
			array(
			'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(10),
		));
		$table = $this->section->addTable();
		$table = $this->section->addTable(array('cellMargin' => 50));
		foreach($this->data['locations'] as $key => $location) {
			if(($key) % 3 == 0) {
				$table->addRow();
			}
			$this->writeLocation($location, $table);
		}
		/*$this->section->addTextBreak(1);
		$this->section->addImage(sprintf("%s/assets/burr-map.jpg", SKM_DOC_WRITER_URL), 
			array(
				'width' => 598.7,
				'height' => 380,
				'align' => 'center'
			)
		);*/
	}

	private function writeLocation($location, $table) {
		$cellStyle = array('gridSpan' => 1, 'valign' => 'top');
		$cell = $table->addCell(4500, $cellStyle);
		
		if(!empty($location['name'])) {
			$cell->addText(
				$location['name'],
				$this->textStyles['location_title'],
				array(
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(8),
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(3),
				)
			);
		}
		//echo $location['address'];
		if(!empty($location['address'])) {
			$ads = explode('<w:br/>', $location['address']);
			foreach ($ads as $ad) {
				$cell->addText(
					trim($ad),
					$this->textStyles['location_address'],
					array(
						'space' => 150,
						'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(0),
						'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(0),
					)
				);
			}
			/*$cell->addText(
				str_replace(' <w:br/> ','<w:br/>',$location['address']),
				$this->textStyles['location_address'],
				array(
					'space' => 150,
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(0),
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(0),
				)
			);*/
		}
		if(!empty($location['suite'])) {
			$cell->addText(
				$location['suite'],
				$this->textStyles['location_address'],
				array(
					'space' => 150,
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(8),
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(0),
				)
			);
		}
		if(!empty($location['address_2'])) {
			$cell->addText(
				$location['address_2'],
				$this->textStyles['location_address'],
				array(
					'space' => 150,
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(8),
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(0),
				)
			);
		}
		if(!empty($location['suite_2'])) {
			$cell->addText(
				$location['suite_2'],
				$this->textStyles['location_address'],
				array(
					'space' => 150,
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(3),
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(0),
				)
			);
		}
		$cityStateZip = array();
		if(!empty($location['city'])) {
			array_push($cityStateZip, $location['city']);
		}
		if(!empty($location['state'])) {
			array_push($cityStateZip, $location['state']);
		}
		$cityStateZip = implode(', ', $cityStateZip);
		if(!empty($location['zip'])) {
			$cityStateZip .= ' ' . $location['zip'];
		}
		if(!empty($cityStateZip)) {
			$cell->addText(
				$cityStateZip,
				$this->textStyles['location_address'],
				array(
					'space' => 150,
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(3),
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(0),
				)
			);
		}

		if(!empty($location['phone'])) {
			$cell->addText(
				"Phone: ". $location['phone'],
				$this->textStyles['location_body'],
				array(
					'space' => 150,
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(3),
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(0),
				)
			);
		}
		if(!empty($location['toll_free'])) {
			$cell->addText(
				"Toll-Free: ". $location['toll_free'],
				$this->textStyles['location_body'],
				array(
					'space' => 150,
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(3),
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(0),
				)
			);
		}
		if(!empty($location['fax'])) {
			$cell->addText(
				"Fax: ". $location['fax'],
				$this->textStyles['location_body'],
				array(
					'space' => 150,
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(3),
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(3),
				)
			);
		}
	}
}