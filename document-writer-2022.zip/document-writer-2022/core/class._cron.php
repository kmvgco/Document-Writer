<?php

class DocWriterCron {

	public static function activate() {
	  wp_schedule_event(time(), 'daily', 'skm_doc_writer_cron');
	}

	public static function deactivate() {
	  wp_clear_scheduled_hook('skm_doc_writer_cron');
	}

	public static function cron_func() {
		foreach(glob(sprintf("%s/tmp/*.docx", SKM_DOC_WRITER_ROOT)) as $file) {
			if(DocWriterCron::fileIsOld($file)) {
				unlink($file);
			}
		}
	}

	public static function fileIsOld($file) {
		$mTime = filemtime($file);
		$now = time();
		$diff = ($now - $mTime) / 60 / 60;
	  return $diff > 12; // returns true for files older than 12 hours
	}
}