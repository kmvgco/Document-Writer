<?php

class DocWriterHooks {
  public function __construct() {
    add_shortcode('word_document_generator', array($this, 'word_document_generator'));
    add_action('wp_enqueue_scripts', array(&$this, 'register_scripts'));
    add_action('rest_api_init', array(&$this, 'register_api_route'));
  }

  public function register_api_route() {
    // This api endpoint is hit by the psuedo form clientside
    register_rest_route('doc-writer/v1', '/doc-writer', array(
      'methods' => 'POST',
      'callback' => array(&$this, 'prepareForDocWrite'),
    ));
  }

  public function register_scripts() {
    wp_register_script('main-js', sprintf("%s/assets/main.js", SKM_DOC_WRITER_URL), array('jquery'));
    wp_register_style('main-css', sprintf("%s/assets/main.css", SKM_DOC_WRITER_URL));
  }

  public function prepareForDocWrite($data) {
    $parser = new DocWriterDataParser($data);  // parser parses on construct
    $writer = new DocWriter($parser->parsedData); // writer does not
    $writer->write(); // write function also saves
    $path = sprintf("%s/downloader.php?file=%s", SKM_DOC_WRITER_URL, $writer->filename);
    return new WP_REST_Response($path, 200);
  }


  public function word_document_generator() {
    // In the name of lighter processing, the shortcode html only consists of each post's title
    // and id.  Those selected are processed more deeply on submit within the parser
  	wp_enqueue_script('main-js');
    wp_enqueue_style('main-css');
  	$services = $this->getServices();
  	$attorneys = $this->getAttorneys();
  	ob_start();  // generating shortcode html with an object buffer
  	?>
      <script type="text/javascript">
        var templateUrl = '<?php echo site_url(); ?>';
      </script>

  		<div id="skm_doc-generator-form" data-valid="false">
  			<div class="input-wrapper">
	  			<label>Company/Proposal Name *</label><br/>
	  			<input type="text" id="proposal-name"/>
  			</div>
			<div class="input-wrapper">
	  			<label>Preparer Name *</label><br/>
	  			<input type="text" id="preparer-name"/>
  			</div>  
  			<div class="input-wrapper">
	  			<label>Generate Face Pages</label><br/>
	  			<input type="checkbox" id="face-pages"/> <span>Yes, generate face pages</span><br/>
  			</div>
  			<div class="input-wrapper picker-outer-wrapper">
	  			<label>SERVICES</label><br/>
		  		<div id="services-picker" class="picker-wrapper" data-type="services">
		  			<div class="available-values values-wrapper">
		  				<?php foreach($services as $service) { ?>
		  					<p class="picker-item" data-id="<?php echo $service->ID; ?>"><?php echo $service->post_title; ?></p>
			  			<?php } ?>
		  			</div>
            <div class="buttons-wrapper">
  		  			<button class="add"></button>
  		  			<button class="remove"></button>
              <button class="up"></button>
              <button class="down"></button>
            </div>
		  			<div class="selected-values values-wrapper"></div>
		  		</div>
	  		</div>
	  		<div class="input-wrapper picker-outer-wrapper">
		  		<label>Attorneys</label><br/>
		  		<div id="attorneys-picker" class="picker-wrapper" data-type="attorneys">
		  			<div class="available-values values-wrapper">
		  				<?php foreach($attorneys as $attorney) { ?>
		  					<p class="picker-item" data-id="<?php echo $attorney->ID; ?>"><?php echo $attorney->last_name . ', ' . $attorney->first_name; ?></p>
			  			<?php } ?>
		  			</div>
		  			<div class="buttons-wrapper">
              <button class="add"></button>
              <button class="remove"></button>
              <button class="up"></button>
              <button class="down"></button>
            </div>
		  			<div class="selected-values values-wrapper"></div>
		  		</div>
	  		</div>
        <div class="bottom">
          <button id="submit">Submit</button>
          <img class="hide loading-gif" src='<?php echo sprintf("%s/assets/loading_spinner.gif", SKM_DOC_WRITER_URL); ?>'/>
        </div>
  		</div>

  
  	<?php
  	return ob_get_clean();
  }

  private function getServices() {
    // clean little query to get ids and titles
  	global $wpdb;

  	$sql = $wpdb->prepare("
  		SELECT ID, post_title FROM $wpdb->posts 
  		WHERE post_type = %s
  		AND post_status = %s
  		ORDER BY post_title
		", 'service', 'publish');

		return $wpdb->get_results($sql, OBJECT);
  }

  private function getAttorneys() {
    // as attorneys names are postmeta, their query is a little more involved
  	global $wpdb;
    
  	$sql = $wpdb->prepare("
  		SELECT DISTINCT $wpdb->posts.ID, pm1.meta_value AS 'first_name', pm2.meta_value AS 'last_name'
  		FROM $wpdb->posts
  		INNER JOIN $wpdb->postmeta AS pm1 ON $wpdb->posts.ID = pm1.post_id
  		INNER JOIN $wpdb->postmeta AS pm2 ON $wpdb->posts.ID = pm2.post_id
  		WHERE post_type = %s
  		AND post_status = %s
  		AND pm1.meta_key = %s
  		AND pm2.meta_key = %s
  		ORDER BY pm2.meta_value
		", 'attorney', 'publish', 'first_name', 'last_name');

		return $wpdb->get_results($sql, OBJECT);
  }
}