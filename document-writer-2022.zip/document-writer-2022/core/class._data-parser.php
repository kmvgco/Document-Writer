<?php 
	class DocWriterDataParser {
		public function __construct($data) {
			$this->fetchLocations();
			$this->fetchIntroText();
			$this->proposalName = $data['proposal_name'];
			$this->preparerName = $data['preparer_name'];
			$this->generateFacePages = $data['generate_face_pages'];
			$this->serviceIds = isset($data['service_ids']) ? $data['service_ids'] : array();
			$this->attorneyIds = isset($data['attorney_ids']) ? $data['attorney_ids'] : array();

			$this->parsedData = array(
				'proposal_name' => $this->proposalName,
				'preparer_name' => $this->preparerName,
				'intro_text' => $this->cover_page_text,
				'generate_face_pages' => $this->generateFacePages,
				'attorneys' => array(),
				'services' => array(),
				'locations' => $this->locations,
			);
			$this->fetchFromPostData();
		}

		private function fetchFromPostData() {
			$this->getServiceData();
			$this->getAttorneyData();
		}

		private function getServiceData() {
			global $wpdb;
			if(count($this->serviceIds) <= 0) { 
				return;
			}

			// wpdb->prepare can't handle arrays, so we implode it instead
			$postIds = implode(',', $this->sanitizedIds($this->serviceIds));
			$order = "CASE";
			foreach($this->sanitizedIds($this->serviceIds) as $i => $id) {
				$order .= " WHEN ID = $id THEN '$i' "; 
			}
			$order .= 'ELSE ID END ASC';
			$sql = "SELECT ID, post_title, post_content FROM $wpdb->posts WHERE ID IN ($postIds) AND post_status = \"publish\" ORDER BY $order";

			// append the conted to our parsedData object.  post_content also contains the 'additional detail' attribute
			$results = $wpdb->get_results($sql, OBJECT);
			foreach($results as $service) {
				$this->parsedData['services'][] = array(
					'post_title' => $service->post_title,
					'post_content' => $this->encode_wysiwyg(apply_filters('the_content', $service->post_content) . apply_filters('the_content', get_field('additional_detail', $service->ID)))
				);
			}
		}

		private function getAttorneyData() {
			$unsortedAttorneyData = array();
			$postIds = $this->sanitizedIds($this->attorneyIds);
			foreach($postIds as $postId) {
				
				// grab all custom fields in one to reduce load
				$fields = get_fields($postId);
				$data = array();
				
				$data['attorney_link'] = $this->encode(get_permalink($postId));
				$data['first_name'] = $this->sanitizedField($fields, 'first_name');
				$data['middle_name'] = $this->sanitizedField($fields, 'middle_name');
				$data['last_name'] = $this->sanitizedField($fields, 'last_name');

				if(is_array($fields['related_office']) && count($fields['related_office']) > 0) {
					$data['office'] = array_map(function($var) {
						return $var->post_title;
					}, $this->sanitizedArrayField($fields, 'related_office'));
					$data['office'] = $data['office'][0];
				}

				if(is_array($fields['remote_office']) && count($fields['remote_office']) > 0) {
					$data['remote_office'] = array_map(function($var) {
						return $var->post_title;
					}, $this->sanitizedArrayField($fields, 'remote_office'));
				}

				$data['title'] = ucwords(str_replace('_', ' ', $this->sanitizedField($fields, 'title')));
				$data['phone'] = $this->sanitizedField($fields, 'phone');
				$data['mobile'] = $this->sanitizedField($fields, 'mobile');
				$data['phone_alt'] = $this->sanitizedField($fields, 'phone_alt');
				// $data['fax'] = $this->sanitizedField($fields, 'fax');
				$data['email'] = $this->sanitizedField($fields, 'email');

				$data['related_services'] = array_map(function($var) {
					return $var->post_title;
				}, $this->sanitizedArrayField($fields, 'related_services'));

				$data['profile_image'] = $this->sanitizedField($fields, 'profile_image');
				$data['elevator_pitch'] = $this->encode(apply_filters('the_content', $fields['elevator_pitch']));
				$data['biography'] = $this->encode(apply_filters('the_content', $fields['biography']));

				$data['education'] = array_map(function($var) {
					return array(
						'school' => $this->sanitizedField($var, 'school'),
						'degree' => $this->sanitizedField($var, 'degree'),
						'years_attended' => $this->sanitizedField($var, 'years_attended'),
					);
				}, $this->sanitizedArrayField($fields, 'education'));

				$data['associations'] = array_map(function($var) {
					return $this->sanitizedField($var, 'association_title');
				}, $this->sanitizedArrayField($fields, 'associations'));

				$data['honors'] = array_map(function($var) {
					return $this->sanitizedField($var, 'name');
				}, $this->sanitizedArrayField($fields, 'honors_awards'));

				$data['licensed_in'] = $this->sanitizedArrayField($fields, 'licensed_in');

				$data['admitted_in'] = array_map(function($var) {
					return $this->encode($var->post_title);
				}, $this->sanitizedArrayField($fields, 'admitted_in'));

				$data['publications'] = $this->getPublicationData($postId);
				$data['paralegal'] = $this->getAssociatedPost($fields, 'paralegal');
				$data['legal_secretary'] = $this->getAssociatedPost($fields, 'legal_secretary');

				$data['community_involvement'] = array_map(function($var) {
					return $this->sanitizedField($var, 'name');
				},$this->sanitizedArrayField($fields, 'community_involvement'));

				$data['experience'] = $this->getAttorneyExperience($postId);
				$unsortedAttorneyData[] = $data;
			}

			$this->parsedData['attorneys'] = $unsortedAttorneyData; // now sorted
		}

		private function getAttorneyExperience($postId) {
			$args = array(
				'post_type' => 'experience',
				'posts_per_page' => 999,
                            'orderby' => 'menu_order',
				'order' => 'ASC',
				'meta_key' => 'related_attorney',
				'meta_value' => '"' . $postId . '"',
				'meta_compare' => 'LIKE'
			);

			$query = new WP_Query($args);
			$parsed_experiences = array();
			if($query->have_posts()) {
				foreach($query->posts as $exp) {
					$parsed_experiences[] = $this->encode_wysiwyg(strip_tags($exp->post_content));
				}
			}
			return $parsed_experiences;
		}

		private function getAssociatedPost($fields, $key) {
			$data = array();

			if(isset($fields[$key]) && is_array($fields[$key]) && count($fields[$key])>0) {
				foreach($fields[$key] as $post) {
					$postFields = get_fields($post->ID);
					$postData = array();
					$postData['name'] = $this->encode($post->post_title);
					$postData['phone'] = $this->sanitizedField($postFields, 'phone');
					$postData['email'] = $this->sanitizedField($postFields, 'email');
					$data[] = $postData;
				}
			}

			return $data;
		}

		private function getPublicationData($attorneyId) {
			$data = array();
			$publications = get_posts(array(
				'post_type' => 'post',
				'category_name' => 'resources',
				'meta_query' => array(
					array(
						'key' => 'related_attorney',
						'value' => '"' . $attorneyId . '"',
						'compare' => 'LIKE'
					)
				)
			));

			foreach($publications as $publication) {
				array_push($data, $this->encode($publication->post_title));
			}

			return $data;
		}

		private function encode_wysiwyg($content) {
			$content = html_entity_decode($content, ENT_QUOTES, 'UTF-8');
			$content = preg_replace('/&lt;/', '<', $content);
			$content = preg_replace('/&gt;/', '>', $content);
			$content = preg_replace('/<\/p>/', "</p>", $content);
			$content = preg_replace('/&/', '&amp;', $content);
			$content = preg_replace('/&amp;/', '&amp;amp;', $content);
			$content = preg_replace('/<br \/>/', '<w:br/>', $content); //<w:br/>
			return $content;
		}

		private function encode($content) {
			$content = htmlentities($content, ENT_QUOTES, 'UTF-8', false);
			$content = $this->encode_wysiwyg($content);
			return $content;
		}

		private function sanitizedField($fields, $key) {
			return isset($fields[$key]) && !empty($fields[$key]) ? $this->encode($fields[$key]) : '';
		}

		private function sanitizedArrayField($fields, $key) {
			return isset($fields[$key]) && is_array($fields[$key]) ? $fields[$key] : array();
		}

		private function sanitizedIds($array) {
			return array_filter(
				array_map(function($var) {
					return intVal($var);
				}, $array), 
				function($var) {
					return is_numeric($var);
				}
			);
		}
		private function fetchLocations() {
			global $wpdb;
			$locations = array();
			$locationsData = get_posts(array(
				'post_type' => 'office',
				'posts_per_page' => -1,
				'post_status' =>'publish',
				'order' => 'ASC',
   				'orderby' => 'title'
			));
			if ($locationsData) {
				foreach ($locationsData as $location) {
					$locationFields = get_fields($location->ID);
					
					if (get_field('featured_image', $location->ID)) {
						$thumb_id = attachment_url_to_postid(get_field('featured_image', $location->ID));
						$thumb_url = wp_get_attachment_image_src($thumb_id, 'thumbnail')[0];
					} else {
						$thumb_url = '';
					}
					//echo $thumb_url;
					$locations[] = array(
						'name' => $this->sanitizedField($locationFields, 'short_name'),
						'address' => $this->sanitizedField($locationFields, 'address'),
						'phone' => $this->sanitizedField($locationFields, 'phone'),
						'toll_free' => $this->sanitizedField($locationFields, 'toll_free'),
						'fax' => $this->sanitizedField($locationFields, 'fax'),
						'thumb' => $thumb_url
					);
						
				}
			}
			//var_dump($locations);
			$this->locations = $locations;


		}
		private function fetchIntroText() {
			ob_start();
			include(SKM_DOC_WRITER_ROOT.'/layout/cover-page-html.php');
			$cdata =ob_get_contents();
			ob_get_clean();

			$this->cover_page_text = $this->encode($cdata);
		}
		private function fetchLocations_old() {
			// locations are currently stubbed.
			// In the future if editing this is desired,
			// a custom post type will suffice, or even just a repeater in an options page

			$this->locations = array(
				array(
					'name' => 'Atlanta',
					'address' => '171 17th Street, NW',
					'suite' => 'Suite 1100',
					'city' => 'Atlanta',
					'state' => 'GA',
					'zip' => '30363',
					'phone' => '(404) 815-3000',
					'toll_free' => '(877) FOR-BURR',
					'fax' => '(404) 817-3244',
				),
				array(
					'name' => 'Birmingham',
					'address' => '420 North 20th Street',
					'suite' => 'Suite 3400',
					'city' => 'Birmingham',
					'state' => 'AL',
					'zip' => '35203',
					'phone' => '(205) 251-3000',
					'toll_free' => '(800) GET-BURR',
					'fax' => '(205) 458-5100',
				),
				array(
					'name' => 'Bluffton',
					'address' => 'The Plaza at Belfair',
					'address_2' => '4 Clarks Summit Drive',
					'suite' => 'Suite 200',
					'city' => 'Bluffton',
					'state' => 'SC',
					'zip' => '29910',
					'phone' => '(843) 815-2171',
				),
				array(
					'name' => 'Charleston',
					'address' => '100 Calhoun Street',
					'suite' => 'Suite 400',
					'city' => 'Charleston',
					'state' => 'SC',
					'zip' => '29401',
					'phone' => '(843) 723-7831',
				),
				array(
					'name' => 'Charlotte',
					'address' => 'Bank of America Plaza',
					'address_2' => '101 South Tryon Street',
					'suite' => 'Suite 2610',
					'city' => 'Charlotte',
					'state' => 'NC',
					'zip' => '28280',
					'phone' => '(704) 785-2171',
				),
				array(
					'name' => 'Columbia',
					'address' => '1221 Main Street',
					'suite' => 'Suite 1800',
					'city' => 'Columbia',
					'state' => 'SC',
					'zip' => '29201',
					'phone' => '(803) 799-9800',
					'toll_free' => '(866) 489-8542',
				),
				array(
					'name' => 'Ft. Lauderdale',
					'address' => 'Las Olas Centre II',
					'address_2' => '350 East Las Olas Blvd',
					'suite' => 'Suite 1440',
					'city' => 'Ft. Lauderdale',
					'state' => 'FL',
					'zip' => '33301',
					'phone' => '(954) 414-6200',
					'fax' => '(954) 414-6201',
				),
				array(
					'name' => 'Greenville',
					'address' => 'Poinsett Plaza',
					'address_2' => '104 South Main Street',
					'suite' => 'Suite 700',
					'city' => 'Greenville',
					'state' => 'SC',
					'zip' => '29601',
					'phone' => '(864) 271-4940',
				),
				array(
					'name' => 'Hilton Head',
					'address' => 'Shelter Cove Executive Park',
					'address_2' => '23-B Shelter Cove Lane',
					'suite' => 'Suite 400',
					'city' => 'Hilton Head Island',
					'state' => 'SC',
					'zip' => '29928',
					'phone' => '(843) 785-2171',
				),
				array(
					'name' => 'Jackson',
					'address' => '190 E Capitol Street',
					'suite' => 'Suite M-100',
					'city' => 'Jackson',
					'state' => 'MS',
					'zip' => '39201',
					'phone' => '(601) 355-3434',
					'toll_free' => '(866) 355-3439',
					'fax' => '(601) 355-5150',
				),
				array(
					'name' => 'Jacksonville',
					'address' => 'Bank of America Tower',
					'address_2' => '50 North Laura Street',
					'suite' => 'Suite 3000',
					'city' => 'Jacksonville',
					'state' => 'FL',
					'zip' => '32202',
					'phone' => '(904) 232-7200',
					'fax' => '(904) 232-7201',
				),
				array(
					'name' => 'Montgomery',
					'address' => '445 Dexter Avenue',
					'suite' => 'Suite 2040',
					'city' => 'Montgomery',
					'state' => 'AL',
					'zip' => '36104',
					'phone' => '(334) 241-7000',
					'toll_free' => '(877) 636-0422',
					'fax' => '(334) 262-0020 ',
				),
				array(
					'name' => 'Mobile',
					'address' => '11 North Water Street',
					'suite' => 'Suite 22200',
					'city' => 'Mobile',
					'state' => 'AL',
					'zip' => '36602',
					'phone' => '(251) 344-5151',
					'toll_free' => '(800) 346-5106',
					'fax' => '(205) 458-5100',
				),
				array(
					'name' => 'Myrtle Beach',
					'address' => 'Founders Centre',
					'address_2' => '2411 Oak Street',
					'suite' => 'Suite 206',
					'city' => 'Myrtle Beach',
					'state' => 'SC',
					'zip' => '29577',
					'phone' => '(843) 444-1107',
				),
				array(
					'name' => 'Nashville',
					'address' => '222 Second Avenue South',
					'suite' => 'Suite 2000',
					'city' => 'Nashville',
					'state' => 'TN',
					'zip' => '37201',
					'phone' => '(615) 724-3200',
					'toll_free' => '(866) 489-8542',
					'fax' => '(615) 724-3290',
				),
				array(
					'name' => 'Orlando',
					'address' => '200 South Orange Avenue',
					'suite' => 'Suite 800',
					'city' => 'Orlando',
					'state' => 'FL',
					'zip' => '32801',
					'phone' => '(407) 540-6600',
					'toll_free' => '(877) 488-2877',
					'fax' => '(407) 540-6601',
				),
				array(
					'name' => 'Raleigh',
					'address' => '421 Fayetteville Street',
					'suite' => 'Suite 1100 Office 1140',
					'city' => 'Raleigh',
					'state' => 'NC',
					'zip' => '27601',
					'phone' => '(919) 334-4708',
					'fax' => '(919) 573-0771',
				),
				array(
					'name' => 'Tampa',
					'address' => 'One Tampa City Center',
					'suite' => 'Suite 3200',
					'address_2' => '201 North Franklin Street',
					'city' => 'Tampa',
					'state' => 'FL',
					'zip' => '33602',
					'phone' => '(813) 221-2626',
					'fax' => '(813) 221-7335',
				),
				array(
					'name' => 'Wilmington',
					'address' => '1201 N. Market Street',
					'suite' => 'Suite 1407',
					'city' => 'Wilmington',
					'state' => 'DE',
					'zip' => '19801',
					'phone' => '(302) 830-2300',
					'fax' => '(302) 830-2301',
				),
			);
		}
	}
?>
