<?php

class AttorneyWriter extends DocWriter  {
	
	public function __construct($data, $doc, $section) {
		$this->doc = $doc;
		$this->section = $section;
		$this->data = $data;
		$this->setTextStyles();
		$this->fullNameFromData();
		$this->cellStyle = array('gridSpan' => 1, 'valign' => 'top');
		$this->cellStyle1 = array('gridSpan' => 5, 'valign' => 'top', 'bgColor' => 'edf0f4');
	}

	public function write() {
		//$this->section->addPageBreak();
		$this->section->addTextBreak(2);
		$table = $this->section->addTable(array('cellMargin' => 0));
		$table->addRow();
		$this->writeImage($table);

		$this->nameCell = $table->addCell(\PhpOffice\PhpWord\Shared\Converter::pointToTwip(259), $this->cellStyle);
		$this->writeName();
		$this->nameCell->addRow();
		$this->writeTitle();
		$this->writeContact();

		if(empty($this->data['paralegal']) && empty($this->data['legal_secretary'])) {
			$this->employeeCell = $table->addCell(\PhpOffice\PhpWord\Shared\Converter::pointToTwip(170), $this->cellStyle);
		} else {
			$this->employeeCell = $table->addCell(\PhpOffice\PhpWord\Shared\Converter::pointToTwip(150), $this->cellStyle);
		}
		$this->writeEmployees();
		$this->writeRelatedServices();

		$this->writeContent();
		
		$this->writeBio();
		$this->writeExperience();
		$this->writeEducation();
		$this->writePublications();
		$this->writeAssociations();
		$this->writeHonorsAwards();
		$this->writeLicensedIn();
		$this->writeAdmittedIn();
		$this->writeCommunityInvolvement();

	}

	public function writeFacePage($table) {
		$this->table = $table;


		$cell = $table->addCell(4500, $this->cellStyle);
		if(!empty($this->data['profile_image'])) {
			$cell->addImage(
				$this->data['profile_image'], 
				array(
					'width' => 100,
				 	'height' => 140
			 	)
			);
		}

		if(!empty($this->fullTitle)) {
			$name = $this->fullTitle;
			$cell->addText(
				htmlspecialchars($name),
				array(
					'name' => 'Calibri',
					'size' => 12,
					'color' => 'ce0c13',
					'lineHeight' => 0.5,
				),
				array(
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(10),
					'spaceAfter' => 0,
					'spacingLineRule' => 'exact',
					'spacing' => 0,
				)
			);
			
		}
		/*$cell->addTextBreak(1);
		$cell->addText('___', array(
			'name' => 'Calibri',
			'size' => 30,
			'color' => '0b134d'
		));*/
		$cell->addImage( SKM_DOC_WRITER_ROOT.'/assets/images/blue-line.jpg', array( 'width'=>30, 'height' =>3, 'align' => 'left', 'wrappingStyle' => 'tight') );

		$textRun = $cell->createTextRun();

		if(!empty($this->data['title'])) {
			$textRun->addText(
				htmlspecialchars($this->data['title']),
				array(
					'name' => 'Calibri',
					'size' => 11,
					'color' => '0b134d'
					
				),
				array(
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(3),
				)
			);
		}

		if(!empty($this->data['title']) && !empty($this->data['office'])) {
			/*$textRun->addText(
				htmlspecialchars(", "),
				array(
					'name' => 'Calibri',
					'size' => 11,
					'color' => '0b134d',
					'italic' => true,
					'bold' => true
				)
			);*/
			$textRun->addTextBreak();
		}

		if(!empty($this->data['office'])) {
			$textRun->addText(
				htmlspecialchars($this->data['office']),
				array(
					'name' => 'Calibri',
					'size' => 11,
					'color' => '0b134d',
					
				)
			);
		}

		if(!empty($this->data['phone'])) {
			$cell->addText(
				htmlspecialchars(sprintf("T: %s", $this->data['phone'])),
				array(
					'name' => 'Calibri',
					'size' => 11,
					'color' => '000000'
				),
				array(
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(3)
				)
			);
		}

		if(!empty($this->data['email'])) {
			$cell->addLink(
				htmlspecialchars(sprintf("mailto:%s", $this->data['email'])),
				htmlspecialchars($this->data['email']),
				array(
					'name' => 'Calibri',
					'size' => 11,
					'color' => '000000'
				),
				null
			);
		}
		
		$cell->addLink(
			htmlspecialchars(sprintf("%s", $this->data['attorney_link'])),
			htmlspecialchars('Bio Link'),
			array(
				'name' => 'Calibri',
				'size' => 11,
				'color' => '000000'
			),
			null
		);

		$cell->addTextBreak(1);
	}

	private function fullNameFromData() {
		$nameParts = array_filter(array(
			$this->data['first_name'],
			$this->data['middle_name'],
			$this->data['last_name'],
		), function($var) {
			return !empty($var);
		});
		$this->fullTitle = implode(' ', $nameParts);
	}

	private function writeImage($table) {
		if(!empty($this->data['profile_image'])) {
			$image = $table->addCell(\PhpOffice\PhpWord\Shared\Converter::pointToTwip(105), $this->cellStyle);
			$image->addImage(
				$this->data['profile_image'], 
				array(
					'width' => 90,
				 	'height' => 125
			 	)
			);
		}
	}

	private function writeName() {
		$name = $this->fullTitle;
		$this->nameCell->addText(
			htmlspecialchars($name),
			array(
				'name' => 'Calibri',
				'size' => 16,
				'color' => 'ce0c13'
			),
			array(
				'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(3),
			)
		);
	}

	private function writeTitle() {
		$titleTable = $this->nameCell->addTable(array('cellMargin' => 0));
		$titleTable->addRow();
		$titleCell = $titleTable->addCell(\PhpOffice\PhpWord\Shared\Converter::pointToTwip(110), $this->cellStyle);
		$titleText = $titleCell->createTextRun();

		if(!empty($this->data['title'])) {
			$titleText->addText(
				htmlspecialchars($this->data['title']),
				array(
					'name' => 'Calibri',
					'size' => 12,
					'color' => '0b134d',
				)
			);
		}
		if(!empty($this->data['office'])) {
			$titleText->addText(
				htmlspecialchars(" | " . $this->data['office']),
				array(
					'name' => 'Calibri',
					'size' => 12,
					'color' => '0b134d',
				)
			);
		}

		$officesCell = $titleTable->addCell(\PhpOffice\PhpWord\Shared\Converter::pointToTwip(170), $this->cellStyle);
		$officesTable = $officesCell->addTable(array('cellMargin' => 0));
		//$officesTable->addRow();
		//$officesCell = $officesTable->addCell(\PhpOffice\PhpWord\Shared\Converter::pointToTwip(170), $this->cellStyle);

		$textRun = $officesCell->createTextRun();


		if(!empty($this->data['remote_office'])) {
			foreach($this->data['remote_office'] as $office) {
				$officesTable->addRow();
				// $officesTable->addCell(\PhpOffice\PhpWord\Shared\Converter::pointToTwip(110), $this->cellStyle);
				$cell = $officesTable->addCell(\PhpOffice\PhpWord\Shared\Converter::pointToTwip(170), $this->cellStyle);
				$cell->addText(
					htmlspecialchars(" | " . $office),
					array(
						'name' => 'Calibri',
						'size' => 13,
						'color' => '0b134d',
						'italic' => true,
					)
				);
			}
		}
	}

	private function writeContact() {
		if(!empty($this->data['phone'])) {
			$this->nameCell->addText(
				htmlspecialchars(sprintf("T: %s", $this->data['phone'])),
				array(
					'name' => 'Calibri',
					'size' => 11,
					'color' => '000000'
				),
				array(
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(10)
				)
			);
		}

		if(!empty($this->data['phone_alt'])) {
			$this->nameCell->addText(
				htmlspecialchars(sprintf("T: %s", $this->data['phone_alt'])),
				array(
					'name' => 'Calibri',
					'size' => 11,
					'color' => '000000',
				)
			);
		}

		if(!empty($this->data['mobile'])) {
			$this->nameCell->addText(
				htmlspecialchars(sprintf("C: %s", $this->data['mobile'])),
				array(
					'name' => 'Calibri',
					'size' => 11,
					'color' => '000000',
				)
			);
		}

		if(!empty($this->data['email'])) {
			$this->nameCell->addLink(
				htmlspecialchars(sprintf("mailto:%s", $this->data['email'])),
				htmlspecialchars($this->data['email']),
				array(
					'name' => 'Calibri',
					'size' => 11,
					'color' => '000000'
				),
				array(
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(10),
				)
			);
		}
	}

	private function writeEmployees() {
		/*$this->employeeCell->addText(
			'__________________________',
			array(
				'name' => 'Calibri',
				'size' => 12,
				'color' => '0b134d',
			)
		);*/
		
		if(!empty($this->data['paralegal'])) {
			$this->data['paralegal'] = str_replace('<p>', "", $this->data['paralegal']);
			$this->data['paralegal'] = str_replace('</p>', "<br/>", $this->data['paralegal']);
			$this->writeEmployeeSection('Paralegal', 'paralegal');
		}
		if(!empty($this->data['legal_secretary'])) {
			$this->data['legal_secretary'] = str_replace('<p>', "", $this->data['legal_secretary']);
			$this->data['legal_secretary'] = str_replace('</p>', "<br/>", $this->data['legal_secretary']);
			$this->writeEmployeeSection('Legal Practice Assistant', 'legal_secretary');
		}
	}

	private function writeEmployeeSection($prefix, $slug) {
		foreach($this->data[$slug] as $i => $employee) {
			$last = $i == (count($this->data[$slug]) - 1);
			$this->writeEmployee($prefix, $slug, $employee, $last);
		}
	}

	private function writeEmployee($prefix, $slug, $employee, $last) {
		$spaceBefore = ($slug == 'paralegal') ? 10 : ($slug == 'legal_secretary' && empty($this->data['paralegal'])) ? 10 : 10;
		if($slug == 'paralegal' && !empty($this->data['legal_secretary'])) {
			$last = false;
		}

		$spaceAfter = $last ? 0 : 10;
		if(!empty($employee['name'])) {
			$this->employeeCell->addText(
				htmlspecialchars(sprintf("%s | %s", $prefix, $employee['name'])),
				array(
					'name' => 'Calibri',
					'size' => 12,
					'color' => '0b134d'
				),
				array(
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip($spaceBefore),
					'indentation' => array('left' => 200, 'right' => 200)
				)
			);
		}

		if(!empty($employee['phone'])) {
			$this->employeeCell->addText(
				htmlspecialchars(sprintf("T: %s", $employee['phone'])),
				array(
					'name' => 'Calibri',
					'size' => 12,
					'color' => '0b134d'
				),
				array('indentation' => array('left' => 200, 'right' => 200), 'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(0))
			);
		}

		if(!empty($employee['email'])) {
			$this->employeeCell->addLink(
				htmlspecialchars(sprintf("mailto:%s", $employee['email'])),
				htmlspecialchars($employee['email']),
				array(
					'name' => 'Calibri',
					'size' => 12,
					'color' => '0b134d'
				),
				array(
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip($spaceAfter),
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(0),
					'indentation' => array('left' => 200, 'right' => 200)
				)
			);
		}
		//$this->employeeCell->addTextBreak(1);
	}

	private function writeRelatedServices() {
		if(!empty($this->data['related_services']) && count($this->data['related_services']) > 0) {
			$relatedServices = sprintf("%s", implode(', ', $this->data['related_services']));

			
			$this->section->addTextBreak(1);
			$this->section->addText(
				htmlspecialchars('Services: '),
				array(
					'name' => 'Calibri',
					'size' => 12,
					'color' => '0b134d',
					'bold' => true
				),
				array(
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(16),
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(16),
				)
			);
			
			$relServices = str_replace('&', '&amp;', $this->data['related_services']);

			$htmlString = '<ul>';
			
			foreach ($relServices as $serve) {
				
				$htmlString .= '<li>'.htmlspecialchars($serve).'</li>';
				
				
			}
			//$htmlString .= "<td>".$relServices[2]."</td>";
			$htmlString .= "</ul>";
			
			$this->renderHTML($htmlString);
			$this->section->addTextBreak(1);
		}
	}

	private function writeContent() {
		if(!empty($this->data['elevator_pitch'])) {
			$this->data['elevator_pitch'] = str_replace('<p>', "<p style='font-size: 12pt; line-height: 1; font-family: Calibri; margin-bottom: 40px;'>", $this->data['elevator_pitch']);
			$this->data['elevator_pitch'] .= "<br/>";
			$this->renderHTML($this->data['elevator_pitch']);
		}
//var_dump($this->data['biography']);
		if(!empty($this->data['biography'])) {
			$this->data['biography'] = str_replace('<p>', "<p style='font-size: 12pt; line-height: 1; font-family: Calibri; margin-top: 20pt;'>", $this->data['biography']);
			$this->data['biography'] = str_replace('</p>', "</p><br/>", $this->data['biography']);
			$this->renderHTML($this->data['biography']);
		}
	}
	
	private function writeExperience() {
		if(!empty($this->data['experience']) && count($this->data['experience']) > 0) {
			$this->section->addText(htmlspecialchars('Experience'),
				array(
					'name' => 'Calibri',
					'size' => 14,
					'spacing' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(1),
					'color' => 'ce0c13',
					'bold' => true,
				),
				array(
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(0),
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(5),
				)
			);
			//$this->addSimpleList($this->data['experience']);
			$htmlString = "";
			foreach($this->data['experience'] as $exp) {
				
				$htmlString .= "<li>$exp</li>";
			}

			$this->renderHTML($htmlString);
		}
	}

	private function writeEducation() {
		if(!empty($this->data['education']) && count($this->data['education']) > 0) {
			$this->section->addText("Education", 
				array(
					'name' => 'Calibri',
					'size' => 14,
					'spacing' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(1.1),
					'color' => 'ce0c13',
					'bold' => true,
				),
				array(
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(14),
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(5),
				)
			);
			$htmlString = "<ul>";
			foreach($this->data['education'] as $edu) {
				$htmlString .= "<li>";
				if(!empty($edu['degree'])) {
					$degree = $edu['degree'];
					$htmlString .= "{$degree}, ";
				}
				if(!empty($edu['school'])) {
					$htmlString .= "{$edu['school']}";
				}
				if(!empty($edu['years_attended'])) {
					$htmlString .= " ({$edu['years_attended']})";
				}
				$htmlString .= "</li>";
			}
			$htmlString .= "</ul>";

			$this->renderHTML($htmlString);
		}
	}

	private function writeAssociations() {
		if(!empty($this->data['associations']) && count($this->data['associations'])) {
			$this->section->addText("Professional Associations",
				array(
					'name' => 'Calibri',
					'size' => 14,
					'spacing' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(1.1),
					'color' => 'ce0c13',
					'bold' => true,
				),
				array(
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(14),
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(5),
				)
			);
			//$this->addSimpleList($this->data['associations']);
			$htmlString = "";
			foreach($this->data['associations'] as $associations) {
				
				$htmlString .= "<li>$associations</li>";
			}

			$this->renderHTML($htmlString);
		}
	}

	private function writeHonorsAwards() {
		if(!empty($this->data['honors']) && count($this->data['honors']) > 0) {
			$this->section->addText(htmlspecialchars('Honors & Awards'), 
				array(
					'name' => 'Calibri',
					'size' => 14,
					'spacing' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(1.1),
					'color' => 'ce0c13',
					'bold' => true,
				),
				array(
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(14),
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(5),
				)
			);
			//$this->addSimpleList($this->data['honors']);
			$htmlString = "";
			foreach($this->data['honors'] as $honors) {
				
				$htmlString .= "<li>$honors</li>";
			}

			$this->renderHTML($htmlString);
		}
	}

	private function writeLicensedIn() {
		if(!empty($this->data['licensed_in']) && count($this->data['licensed_in']) > 0) {
			$this->section->addText("Licensed In", 
				array(
					'name' => 'Calibri',
					'size' => 14,
					'spacing' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(1.1),
					'color' => 'ce0c13',
					'bold' => true,
				),
				array(
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(14),
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(5),
				)
			);
			//$this->addSimpleList($this->data['licensed_in']);
			$htmlString = "";
			foreach($this->data['licensed_in'] as $licensed) {
				
				$htmlString .= "<li>$licensed</li>";
			}

			$this->renderHTML($htmlString);
		}
	}

	private function writeAdmittedIn() {
		if(!empty($this->data['admitted_in']) && count($this->data['admitted_in']) > 0) {
			$this->section->addText("Admitted In",
				array(
					'name' => 'Calibri',
					'size' => 14,
					'spacing' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(1.1),
					'color' => 'ce0c13',
					'bold' => true,
				),
				array(
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(14),
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(5),
				)
			);
			//$this->addSimpleList($this->data['admitted_in']);
			$htmlString = "";
			foreach($this->data['admitted_in'] as $admitted) {
				
				$htmlString .= "<li>$admitted</li>";
			}

			$this->renderHTML($htmlString);
		}
	}

	private function writePublications() {
		if(!empty($this->data['publications']) && count($this->data['publications']) > 0) {
			$this->section->addText("Publications",
				array(
					'name' => 'Calibri',
					'size' => 14,
					'spacing' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(1.1),
					'color' => 'ce0c13',
					'bold' => true,
				),
				array(
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(12),
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(5),
				)
			);
			//$this->addSimpleList($this->data['publications']);
			$htmlString = "";
			foreach($this->data['publications'] as $publication) {
				
				$htmlString .= "<li>$publication</li>";
			}

			$this->renderHTML($htmlString);
		}
	}

	private function writeCommunityInvolvement() {
		if(!empty($this->data['community_involvement']) && count($this->data['community_involvement']) > 0) {
			$this->section->addText("Community Involvement",
				array(
					'name' => 'Calibri',
					'size' => 14,
					'spacing' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(1.1),
					'color' => 'ce0c13',
					'bold' => true,
				),
				array(
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(14),
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(5),
				)
			);
			//$this->addSimpleList($this->data['community_involvement']);
			$htmlString = "";
			foreach($this->data['community_involvement'] as $involvement) {
				
				$htmlString .= "<li>$involvement</li>";
			}

			$this->renderHTML($htmlString);
		}
	}

	private function writeBio() {
		if(!empty($this->data['bio_sections']) && count($this->data['bio_sections']) > 0) {
			$this->section->addText("Bio", 
				array(
					'name' => 'Calibri',
					'size' => 14,
					'spacing' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(1.1),
					'color' => 'ce0c13',
					'bold' => true,
				),
				array(
					'spaceBefore' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(14),
					'spaceAfter' => \PhpOffice\PhpWord\Shared\Converter::pointToTwip(5),
				)
			);
			$this->renderHTML("<ul>");
			foreach($this->data['bio_sections'] as $bio) {
				$this->renderHTML("<li>");
				$this->renderHTML("<b>".$bio['section_title']."</b>");
				$this->renderHTML("<br>");
				$this->renderHTML($bio['section_copy']);
				$this->renderHTML("<br>");
				$this->renderHTML("</li>");
				$this->renderHTML('<p></p>');
			}
			$this->renderHTML("</ul>");

			
		}
	}
}
