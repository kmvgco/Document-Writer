<?php
// This file is requested with a filename query param.
// It allows for the file downloading and deletes the tmp file
if(!isset($_GET['file']) || !file_exists(sprintf("%s/tmp/%s", dirname(__FILE__), $_GET['file']))) {
	die();
}

$file = sprintf("%s/tmp/%s", dirname(__FILE__), $_GET['file']);
header("Content-Disposition: attachment; filename=Burr & Forman Brochure.docx");
readfile($file);
unlink($file);