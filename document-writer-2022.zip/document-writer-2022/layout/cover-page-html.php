<h1>Burr Knows...</h1>
<img src="<?= SKM_DOC_WRITER_ROOT; ?>/assets/images/line.jpg" width="30" height="10"/>
   
<p>&nbsp;</p>
<table width="100%" cellspacing="5" cellpadding="5">
<tr>
<td>
<img src="<?= SKM_DOC_WRITER_ROOT; ?>/assets/images/ico-check.png" width="50" height="40"/>
</td>
<td>
<h2>Bankruptcy</h2>
<p style="font-size:16pt; line-height:120%; margin-top: 240pt;">Burr & Forman’s commitment to the changing needs of lenders and creditors is evidenced by its substantial Creditors’ Rights and Bankruptcy practice. We have one of the largest bankruptcy practice groups in the Southeast with over 40 attorneys concentrating in this area of law. For decades, Burr & Forman attorneys concentrating in creditors’ rights have been actively involved in major bankruptcy proceedings in the Southeast and beyond. Along with our expanding representation in creditors’ rights cases, we also counsel and represent business entities experiencing financial distress.</p>
</td>
</tr>
</table>
<p>&nbsp;</p>
<table width="100%" cellspacing="5" cellpadding="5">
<tr>
<td>
<img src="<?= SKM_DOC_WRITER_ROOT; ?>/assets/images/ico-check.png" width="50" height="40"/>
</td>
<td>
<h2>Entertainment</h2>
<p style="font-size:16pt; line-height:120%; margin-top: 240pt;">Our entertainment attorneys serve sports-related companies, sports leagues, entertainment and media companies, athletes, music industry professionals, artists, songwriters, production companies, record labels and publishers. Burr & Forman attorneys represent the interests of professional and amateur sports organizations and related businesses with a full range of legal services designed specifically for the sports industry. We handle a variety of matters including, but not limited to the following:</p>
<table width="100%">
    <tr>
        <td>
            <ul>
                <li>Bankruptcy & Creditor’s Rights</li>
                <li>Event hosting</li>
                <li>Event sponsorships</li>
                <li>Licensing</li>
            </ul>
        </td>
        <td>
             <ul>
                <li>Media rights</li>
                <li>Stadium financing & construction</li>
                <li>Television time buys</li>
                <li>Venue leases</li>
            </ul>        
        </td>
    </tr>
</table>
</td>
</tr>
</table>
<p>&nbsp;</p>
<table width="100%" cellspacing="5" cellpadding="5">
<tr>
<td>
<img src="<?= SKM_DOC_WRITER_ROOT; ?>/assets/images/ico-check.png" width="50" height="40"/>
</td>
<td>
<h2>Creditors’ Committees</h2>
<p style="font-size:16pt; line-height:120%; margin-top: 240pt;">We have extensive experience representing official creditors’ committees, bank debt and ad hoc creditor groups, secured lenders, equity holders, derivative and swap counterparties, and other creditors in out-of-court reorganizations, debt restructurings, enforcement processes, liability management strategies, and bankruptcy proceedings. Burr & Forman has been counsel for and involved with multiple Unsecured Creditors' Committees.</p>
</td>
</tr>
</table>
<p>&nbsp;</p>
  
<h1 class="introHeading">Creditors’ Committee Representation</h1>
<img src="<?= SKM_DOC_WRITER_ROOT; ?>/assets/images/line.jpg" width="30" height="10"/>
   
<p style="font-size:16pt; line-height:120%;">Our creditor committee representation is able to advise the committee on all matters pertinent to Chapter 11 proceedings, including, among other things:</p>
<ul class="listFull">
    <li>Most effective and efficient means of maximizing value for unsecured creditors</li>
    <li>Debtor’s ability to sell substantially all of its assets with expedited notice</li>
    <li>Debtor financing & restructuring strategy</li>
    <li>Validity and/or extent of secured creditors’ liens and claims</li>
    <li>Validity and prosecution of potential bankruptcy and non-bankruptcy related causes of action</li>
    <li>Valuation and solvency of a debtor and/or its assets</li>
</ul>
<p>&nbsp;</p>
<p>&nbsp;</p>
    
<h2>Typical engagements include:</h2>
<ul>
    <li>Representing debtors, committees, and major creditors in Chapter 11 cases</li>
    <li>Acquiring assets, including going concern companies, through bankruptcy cases</li>
    <li>Negotiating and litigating the terms of debtor-in-possession financing, use of cash collateral, adequate protection, and relief from automatic stay </li>
    <li>Participating in the Chapter 11 Plan process, including drafting and confirming creditors’ and debtors’ Chapter 11 plans</li>
    <li>Prosecuting or defending fraudulent transfer and preference actions as well as equitable subordination actions</li>
    <li>Establishing, negotiating, and litigating breach of fiduciary duty and other D & O claims, and preference, fraudulent conveyance, and other avoidance actions</li>
</ul>
<p>&nbsp;</p>
  
<h1 class="introHeading">Representative Experience</h1>
<img src="<?= SKM_DOC_WRITER_ROOT; ?>/assets/images/line.jpg" width="30" height="10"/>
      
<p style="font-size:16pt; line-height:120%;">Burr & Forman served as counsel to the unsecured creditors committee of <b>G.L. McNeal, Inc.</b> and obtained a 100% plus interest recovery for unsecured creditors.</p>
<p>&nbsp;</p>
<p style="font-size:16pt; line-height:120%;">Burr & Forman served as counsel to the unsecured creditors committee in the bankruptcy case of <b>Daniels Capitol Corporation</b> and negotiated a payout to unsecured creditors that will pay those creditors back all of their actual out-of-pocket money, plus interest.</p>