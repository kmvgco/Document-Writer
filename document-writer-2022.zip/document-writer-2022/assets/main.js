jQuery(document).ready(function() {
	var selected = {
		services: [],
		attorneys: [],
	}

	$ = jQuery;
	var chars = "";
	var timeout;
	$(document).on('keydown', function(event) {
		var $item = $('.picker-item.active');
		if($item.length == 0) return;
		$parent = $item.parents('.values-wrapper');
		var keyCode = event.keyCode || event.which;
		var char = String.fromCharCode(keyCode).toLowerCase();
		if("abcdefghijklmnopqrstuvwxyz ".indexOf(char) < 0) return;
		chars += char;
		clearTimeout(timeout);
		timeout = setTimeout(function() {
			chars = "";
		}, 350);
		scrollToCharacterInParent($parent, chars);
	});

	scrollToCharacterInParent = function($parent, chars) {
		$items = $parent.find('.picker-item');
		if($items.length == 0) return;
		var selectedIndex, n, firstChar;
		for(n = 0; n < $items.length; n++) {
			if($items[n].innerHTML.toLowerCase().indexOf(chars) == 0) {
				selectedIndex = n;
				break;
			}
		}
		if(selectedIndex !== undefined) {
			var itemRect = $items[selectedIndex].getBoundingClientRect();
			var parentRect = $parent[0].getBoundingClientRect();
			var scrollTo = itemRect.top - parentRect.top - $parent.scrollTop();
			$parent.scrollTop(itemRect.top - parentRect.top + $parent.scrollTop());
		}
	}

	$('#skm_doc-generator-form').on('click', '.picker-item', function(event) {
		if($(this).hasClass('disabled')) return;
		$parent = $(this).parents('.picker-wrapper');
		$('.picker-item').removeClass('active');
		$(this).addClass('active');
		//$(this).toggleClass('active');
	})

	$('#skm_doc-generator-form button.add').click(function() {
		var $parent = $(this).parents('.picker-wrapper');
		var $item = $parent.find('.available-values .picker-item.active');
		var $selectedWrapper = $parent.find('.selected-values');
		var data = selected[$parent.data().type];
		if($item.length > 0 && data.indexOf($item.data().id) == -1) {
			$item.removeClass('active');
			$selectedWrapper.append($item.clone());
			$item.addClass('disabled');
			selected[$parent.data().type].push($item.data().id);
			$('#download').addClass('hidden');
		}
	});

	function sortItems($selectedWrapper) {
		var items = $selectedWrapper.children().sort(function(a, b) { return $(a).text() > $(b).text() })

		$selectedWrapper.innerHTML = ""
		$selectedWrapper.append(items);
	}

	$('#skm_doc-generator-form button.remove').click(function() {
		var $parent = $(this).parents('.picker-wrapper');
		var $item = $parent.find('.selected-values .picker-item.active');
		var $availableWrapper = $parent.find('.available-values');
		var data = selected[$parent.data().type];
		if($item.length > 0) {
			selected[$parent.data().type].splice(data.indexOf($item.data().id), 1);
			$item.remove();
			$availableWrapper.find('.picker-item[data-id="'+$item.data().id+'"]').removeClass('disabled');
			$('#download').addClass('hidden');
		}
	});

	$('#skm_doc-generator-form button.up').click(function() {
		var $parent = $(this).parents('.picker-wrapper');
		var $item = $parent.find('.selected-values .picker-item.active');
		var data = selected[$parent.data().type];
		var $items = $parent.find('.selected-values .picker-item');
		var selectedIndex = 0;
		for(var i = 0; i < $items.length; i++) {
			if($items[i].className.indexOf('active') > 0) {
				selectedIndex = i;
			}
		}
		if(selectedIndex > 0) {
			var val1 = $item.data().id;
			var val2 = $($items[selectedIndex - 1]).data().id;
			swapValues(val1, val2, $parent.data().type);
			$($items[selectedIndex - 1]).before($item);
		}
	});

	swapValues = function(val1, val2, type) {
		var prevIndex1 = selected[type].indexOf(val1);
		var prevIndex2 = selected[type].indexOf(val2);
		selected[type][prevIndex1] = val2;
		selected[type][prevIndex2] = val1;
	}

	$('#skm_doc-generator-form button.down').click(function() {
		var $parent = $(this).parents('.picker-wrapper');
		var $item = $parent.find('.selected-values .picker-item.active');
		var data = selected[$parent.data().type];
		var $items = $parent.find('.selected-values .picker-item');
		var selectedIndex = $items.length;
		for(var i = 0; i < $items.length; i++) {
			if($items[i].className.indexOf('active') > 0) {
				selectedIndex = i;
			}
		}
		if(selectedIndex < $items.length) {
			var val1 = $item.data().id;
			var val2 = $($items[selectedIndex + 1]).data().id;
			swapValues(val1, val2, $parent.data().type);
			$($items[selectedIndex + 1]).after($item);
		}
	});

	postDataIsValid = function(postData) {
		var valid = true;
		if(!postData.proposal_name) {
			alert("Please enter a proposal name.");
			valid = false;
		}
		else if(!postData.preparer_name) {
			alert("Please enter a preparer name.");
			valid = false;
		}
		return valid;
	}

	$('#skm_doc-generator-form #submit').click(function(event) {
		$('#download').addClass('hidden');
		$('#skm_doc-generator-form #submit').attr('disabled', true);
		var postData = {
			proposal_name: $('#proposal-name').val(),
			preparer_name : $('#preparer-name').val(),
			generate_face_pages: $('#face-pages:checkbox:checked').length > 0,
			service_ids: selected.services,
			attorney_ids: selected.attorneys,
		}
		if(!postDataIsValid(postData)) {
			event.preventDefault();
			$('#skm_doc-generator-form #submit').attr('disabled', false);
			return;
		}
		$('#skm_doc-generator-form .loading-gif').removeClass('hide');
		$.ajax({
			type: 'POST',
			url: templateUrl + '/wp-json/doc-writer/v1/doc-writer',
			data: postData,
			success: function(data) {
				$('#skm_doc-generator-form .loading-gif').addClass('hide');
				$('#skm_doc-generator-form #submit').attr('disabled', false);
				$('#skm_doc-generator-form #doc_download').remove();
				$('#skm_doc-generator-form').append("<a id='doc_download' href='" + data + "' onclick='clickAndDisable(this)'>Download Brochure</a>");
			},
			error: function(request, data, error) {
				$('#skm_doc-generator-form .loading-gif').addClass('hide');
				$('#skm_doc-generator-form #submit').attr('disabled', false);
				alert("An error occurred.  Please try again.");
			},
		});
	});
});

function clickAndDisable(link) {
	link.remove();
}