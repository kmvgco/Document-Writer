<?php

foreach(glob(sprintf("%s/core/*.php", SKM_DOC_WRITER_ROOT)) as $file) {
	require_once($file);
}
require('vendor/autoload.php');
//require_once(__DIR__ .'/vendor/phpoffice/phpword/src/PhpWord/Autoloader.php');